Page({
	navigateToPage1: function () {
			wx.navigateTo({
					url: '/pages/calculator/calculator'
			});
	},
	navigateToPage2: function () {
			wx.navigateTo({
					url: '/pages/bloodtype/bloodtype'
			});
	},
	navigateToPage3: function () {
			wx.navigateTo({
					url: '/pages/converter/converter'
			});
	},
	navigateToPage4: function () {
			wx.navigateTo({
					url: '/pages/speedtest/speedtest'
			});
	},
	navigateToPage5: function () {
			wx.navigateTo({
					url:'/pages/feedback/feedback'
			});
	},
	navigateToPage6: function () {
			wx.navigateTo({
					url: '/pages/calc/calc'
			});
	},
	navigateToPage7: function () {
			wx.navigateTo({
					url: '/pages/passwd/passwd'
			});
	},
	navigateToPage8: function () {
			wx.navigateTo({
					url: '/pages/phone/phone'
			});
	},
	navigateToPage9: function () {
			wx.navigateTo({
					url: '/pages/tp/tp'
			});
	},
	navigateToPage10: function () {
			wx.navigateTo({
					url: '/pages/kinship/kinship'
			});
	},
	navigateToPage11: function () {
			wx.navigateTo({
					url: '/pages/page8/page8'
			});
	},
	navigateToPage12: function () {
			wx.navigateTo({
					url: '/pages/page9/page9'
			});
	},
	navigateToPage13: function () {
			wx.navigateTo({
					url:'/pages/qrcodeGenerator/qrcodeGenerator'
			});
	}
});    